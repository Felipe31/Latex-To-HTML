#include <stdio.h>
#include "latexTOhtml.h"


FILE * arqG;
void title(char *title)
{
    fprintf(arqG, "<!doctype html>\n<html>\n<head>\n");
    fprintf(arqG, "<title>%s</title>\n", title);
    fprintf(arqG, "</head>\n<body>\n");
    fprintf(arqG, "<center><h1>%s</h1></center>\n", title);

}
void yyerror(char *s, ...){}
// TITULO      "\\title"
// NEGRITO     "\\textbf"
//
// SUBLINHADO  "\\underline"
//
// ITALICO     "\\textit"
//
//
// AUTOR       "\\author"
//
// CLASSE      "\\documentclass"
//
// letra       [a-z]
//
// letraM 	    [A-Z]
//
// digito 	    [0-9]
//
// NOME        ({letra}|{letraM})({letra}|{letraM}|{digito})*
//
// CONTEUDO    "{"(.)*"}
//
//
// COMENTARIO  "%"(.)*\n


int main ()
{
    arqG = fopen(".//saida.html","w");
    //char t[] = {"Titulo Legal"};
    //title(&t);asd

    yyparse();

    fclose(arqG);

}
