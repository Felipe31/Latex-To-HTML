#ifndef _LATEXTOHTML_
#define _LATEXTOHTML_
// ibison
extern int yylineno;
//void yyerror(char const *s, ...);
int yyparse(void);
int yylex(void);

void title(char *title);

#endif
